class Quarto:
    def __init__(self, numeroquart, tipo):
        self.numeroquart = numeroquart
        self.tipo = tipo
        self.ocupado = False
    